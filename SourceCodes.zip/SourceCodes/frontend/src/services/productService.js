export async function getAllProducts() {
  const res = await fetch("http://localhost:8080/api/products");
  return res.json();
}

export async function getProductsByCategory(category) {
  const res = await fetch(
    `http://localhost:8080/api/products/category/${category}`
  );
  return res.json();
}
export async function searchProducts(query, minPrice, maxPrice, sort) {
  // Build the URL with query params
  const params = new URLSearchParams({ q: query });
  
  if (minPrice) params.append("min", minPrice);
  if (maxPrice) params.append("max", maxPrice);
  if (sort) params.append("sort", sort);

  const res = await fetch(`http://localhost:8080/api/products/search?${params.toString()}`);
  return res.json();
}