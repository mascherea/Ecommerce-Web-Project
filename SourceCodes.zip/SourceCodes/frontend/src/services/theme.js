// src/theme.js
import { createTheme } from "@mui/material/styles";

export const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#1976d2", // Or use a brand color like Trendyol Orange: #f27a1a
    },
    secondary: {
      main: "#ff9800",
    },
    background: {
      default: "#f5f5f5", // Light gray background for the whole app
      paper: "#ffffff",
    },
    text: {
      primary: "#333333",
      secondary: "#666666",
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h6: {
      fontWeight: 600, // Make titles bold
    },
    button: {
      textTransform: "none", // Stop buttons from being ALL CAPS
      fontWeight: 600,
    },
  },
  shape: {
    borderRadius: 8, // Soften the corners
  },
});