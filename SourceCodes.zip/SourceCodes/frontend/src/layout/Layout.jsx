import Navbar from "../components/Navbar";
import CategoryBar from "./CategoryBar"; // Or wherever you kept it
import Footer from "../components/Footer"; // Import the new footer
import { Outlet } from "react-router-dom";
import { Container, Box } from "@mui/material";

export default function Layout() {
  return (
    <Box 
      sx={{ 
        display: 'flex', 
        flexDirection: 'column', 
        minHeight: '100vh' // This ensures the app takes full screen height
      }}
    >
      <Navbar />
      
      {/* Container wraps the main content */}
      <Container maxWidth="lg" sx={{ flexGrow: 1, py: 3 }}>
        {/* We keep CategoryBar here if you want it on every page, 
            or remove it if you only want it on Home */}
        <CategoryBar />
        <Outlet />
      </Container>

      <Footer />
    </Box>
  );
}