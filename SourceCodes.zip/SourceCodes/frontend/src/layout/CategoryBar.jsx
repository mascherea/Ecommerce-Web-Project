import { useEffect, useState } from "react";
import { Box, Typography, Avatar } from "@mui/material";
import { Link } from "react-router-dom";

export default function CategoryBar() {
  const [categories, setCategories] = useState([]);

  // Fetch categories from Backend
  useEffect(() => {
    fetch("http://localhost:8080/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data))
      .catch((err) => console.error("Error fetching categories:", err));
  }, []);

  if (categories.length === 0) {
    return null; // Don't show anything until loaded
  }

  return (
    <Box 
      sx={{ 
        display: "flex", 
        gap: 4, 
        py: 3, 
        justifyContent: "center", 
        overflowX: "auto", 
        bgcolor: "background.paper", 
        mb: 2 
      }}
    >
      {categories.map((cat) => (
        <Box 
          key={cat.id} // Use ID from database
          component={Link} 
          to={`/category/${cat.name}`} 
          sx={{ 
            textDecoration: "none", 
            textAlign: "center", 
            cursor: "pointer", 
            "&:hover": { opacity: 0.8 },
            minWidth: 80 // Prevents squishing on small screens
          }}
        >
          <Avatar 
            src={cat.imageUrl} // Note: Java sends "imageUrl", not "img"
            alt={cat.name}
            sx={{ 
              width: 64, 
              height: 64, 
              mb: 1, 
              border: "2px solid #eee", 
              mx: "auto",
              bgcolor: 'transparent' // Often looks better for icons
            }} 
            imgProps={{ style: { objectFit: 'contain', padding: '10px' } }} // Fits icons nicely inside circle
          />
          <Typography variant="caption" color="text.primary" fontWeight="bold">
            {cat.name}
          </Typography>
        </Box>
      ))}
    </Box>
  );
}