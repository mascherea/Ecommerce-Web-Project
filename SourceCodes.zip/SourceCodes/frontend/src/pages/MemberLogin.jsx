import { useState } from "react";
import { Container, TextField, Button, Typography, Paper, Box, Alert } from "@mui/material";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function MemberLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState(""); 
  const [error, setError] = useState(""); // 1. New State for Error Message

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(""); // Clear previous errors on new attempt
  
    try {
      const response = await fetch("http://localhost:8080/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }), 
      });

      if (response.ok) {
        const userData = await response.json();
        login(userData);
        navigate("/profile");
      } else {
        // 2. Instead of alert(), set the Error state
        const errorMsg = await response.text(); 
        setError(errorMsg || "Invalid Username or Password");
      }
    } catch (err) {
      console.error("LOGIN FAILED:", err);
      // 3. Set a friendly error message for server issues
      setError("Server error. Is the backend running?");
    }
  };

  return (
    <Container maxWidth="xs" sx={{ mt: 8 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h5" align="center" gutterBottom>
          Login Required
        </Typography>
        <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
          Please login to manage your account and shop.
        </Typography>

        {/* 4. DISPLAY ERROR HERE IF IT EXISTS */}
        {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
                {error}
            </Alert>
        )}
        
        <Box component="form" onSubmit={handleLogin} display="flex" flexDirection="column" gap={2}>
          
          <TextField
            label="Username"
            variant="outlined"
            fullWidth
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            error={!!error} // Turn input red on error
          />

          <TextField
            label="Password"
            type="password"
            variant="outlined"
            fullWidth
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            error={!!error} // Turn input red on error
          />

          <Button type="submit" variant="contained" size="large" fullWidth>
            Login
          </Button>

          <Button sx={{ mt: 2, width: '100%' }} onClick={() => navigate("/register")}>
            Don't have an account? Register
          </Button>

        </Box>
      </Paper>
    </Container>
  );
}