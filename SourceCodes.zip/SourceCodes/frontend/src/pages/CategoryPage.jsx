import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { Grid, Container, Typography, Box } from "@mui/material";
import { getProductsByCategory } from "../services/productService";
import ProductCard from "../components/ProductCard";

export default function CategoryPage() {
  const { name } = useParams();
  const [products, setProducts] = useState([]);
  

  useEffect(() => {
    getProductsByCategory(name).then(setProducts);
  }, [name]);

  // 1. Calculate the highest review count in the current list
  // We use (p.reviewCount || 0) just in case the backend sends a null
  const maxReviews = Math.max(...products.map(p => p.reviewCount || 0));

  return (
    <Container sx={{ mt: 4, mb: 8 }}>
      <Typography variant="h4" sx={{ mb: 4, fontWeight: 'bold', textTransform: 'capitalize' }}>
        {name} Products
      </Typography>

      {products.length === 0 ? (
         <Typography variant="body1">Loading products...</Typography>
      ) : (
        <Grid container spacing={3}>
          {products.map((p) => (
            <Grid item xs={12} sm={6} md={4} key={p.id}>
              <ProductCard 
                product={p} 
                // 2. The magic logic: Only true if this product is the winner
                isBestSeller={p.reviewCount === maxReviews && maxReviews > 0}
              />
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
}