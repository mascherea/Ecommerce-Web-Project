import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { 
  Container, Grid, Typography, Box, TextField, 
  Button, MenuItem, Select, FormControl, InputLabel, Paper 
} from "@mui/material";
import ProductCard from "../components/ProductCard";
import { searchProducts } from "../services/productService";

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get("q");

  // State for Filters
  const [products, setProducts] = useState([]);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [sort, setSort] = useState(""); // "asc" or "desc"

  // Fetch data whenever query or filters change
  useEffect(() => {
    if (query) {
      searchProducts(query, minPrice, maxPrice, sort).then(setProducts);
    }
  }, [query, minPrice, maxPrice, sort]);

  // Handlers
  const clearFilters = () => {
    setMinPrice("");
    setMaxPrice("");
    setSort("");
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 8 }}>
      <Typography variant="h4" sx={{ mb: 4, fontWeight: 'bold' }}>
        Results for "{query}"
      </Typography>

      <Grid container spacing={4}>
        
        {/* LEFT SIDEBAR - FILTERS */}
        <Grid item xs={12} md={3}>
          <Paper elevation={3} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>Filter & Sort</Typography>
            
            {/* Price Filter */}
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" gutterBottom>Price Range</Typography>
              <Grid container spacing={1}>
                <Grid item xs={6}>
                  <TextField 
                    label="Min" 
                    type="number" 
                    size="small" 
                    fullWidth 
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField 
                    label="Max" 
                    type="number" 
                    size="small" 
                    fullWidth 
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                  />
                </Grid>
              </Grid>
            </Box>

            {/* Sort Dropdown */}
            <Box sx={{ mb: 3 }}>
              <FormControl fullWidth size="small">
                <InputLabel>Sort By</InputLabel>
                <Select
                  value={sort}
                  label="Sort By"
                  onChange={(e) => setSort(e.target.value)}
                >
                  <MenuItem value=""><em>Relevance</em></MenuItem>
                  <MenuItem value="asc">Price: Low to High</MenuItem>
                  <MenuItem value="desc">Price: High to Low</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Button variant="outlined" fullWidth onClick={clearFilters}>
              Clear Filters
            </Button>
          </Paper>
        </Grid>

        {/* RIGHT SIDE - RESULTS */}
        <Grid item xs={12} md={9}>
          {products.length === 0 ? (
            <Box textAlign="center" mt={5}>
              <Typography variant="h6" color="text.secondary">
                No products found matching your criteria.
              </Typography>
            </Box>
          ) : (
            <Grid container spacing={3}>
              {products.map((p) => (
                <Grid item xs={12} sm={6} md={4} key={p.id}>
                  <ProductCard product={p} />
                </Grid>
              ))}
            </Grid>
          )}
        </Grid>

      </Grid>
    </Container>
  );
}