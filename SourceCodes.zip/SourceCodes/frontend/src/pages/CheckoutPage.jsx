import { useState } from "react";
import { Container, Grid, Paper, Typography, TextField, Button, Box, Divider, List, ListItem, ListItemText } from "@mui/material";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";

export default function CheckoutPage() {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  
  // --- STATE FOR FIELDS ---
  const [address, setAddress] = useState("");
  
  // Split payment into 3 separate states for better control
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  
  // State for Error Messages
  const [errors, setErrors] = useState({}); 

  const [isOrderPlaced, setIsOrderPlaced] = useState(false);
  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

  // --- 1. CARD NUMBER LOGIC (Only Numbers, Max 12) ---
  const handleCardChange = (e) => {
    // Regex: Replace anything that is NOT a number (0-9) with empty string
    const value = e.target.value.replace(/\D/g, ""); 
    if (value.length <= 12) {
        setCardNumber(value);
        // Clear error if they fix it
        if (errors.cardNumber) setErrors({ ...errors, cardNumber: "" });
    }
  };

  // --- 2. EXPIRY DATE LOGIC (MM/YY Format) ---
  const handleExpiryChange = (e) => {
    // Remove non-numbers
    let value = e.target.value.replace(/\D/g, ""); 
    
    // Limit to 4 numbers total (MMYY)
    if (value.length > 4) value = value.slice(0, 4);

    // If they typed more than 2 numbers, add the Slash
    if (value.length > 2) {
        value = `${value.slice(0, 2)}/${value.slice(2)}`;
    }
    
    setExpiry(value);
    if (errors.expiry) setErrors({ ...errors, expiry: "" });
  };

  // --- 3. CVV LOGIC (Only Numbers, Max 3) ---
  const handleCvvChange = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value.length <= 3) {
        setCvv(value);
        if (errors.cvv) setErrors({ ...errors, cvv: "" });
    }
  };

  // --- VALIDATION ON SUBMIT ---
  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

    if (!address.trim()) {
        newErrors.address = "Address is required";
        isValid = false;
    }

    if (cardNumber.length !== 12) {
        newErrors.cardNumber = "Card must be exactly 12 digits";
        isValid = false;
    }

    // Check Date Length AND Month Validity (01-12)
    if (expiry.length !== 5) {
        newErrors.expiry = "Invalid Date";
        isValid = false;
    } else {
        const month = parseInt(expiry.substring(0, 2));
        if (month < 1 || month > 12) {
            newErrors.expiry = "Invalid Month";
            isValid = false;
        }
    }

    if (cvv.length !== 3) {
        newErrors.cvv = "CVV must be 3 digits";
        isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    
    // Run validation before sending
    if (!validateForm()) return;

    const productIds = cart.map(item => item.id);

    try {
        const response = await fetch("http://localhost:8080/api/products/purchase", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(productIds)
        });

        if (response.ok) {
            setIsOrderPlaced(true);
            clearCart();
        } else {
            alert("Error placing order. Some items might be out of stock!");
        }
    } catch (error) {
        console.error("Order failed:", error);
        alert("Server connection failed.");
    }
  };

  // --- VIEW 1: SUCCESS ---
  if (isOrderPlaced) {
    return (
        <Container maxWidth="sm" sx={{ mt: 8, textAlign: 'center' }}>
            <Paper elevation={3} sx={{ p: 5 }}>
                <Typography variant="h4" color="success.main" gutterBottom>Order Confirmed!</Typography>
                <Typography variant="body1" sx={{ mb: 3 }}>Thank you! Your supplements are on the way to:</Typography>
                <Typography variant="h6" sx={{ fontStyle: 'italic', mb: 4 }}>"{address}"</Typography>
                <Button variant="contained" onClick={() => navigate("/")}>Return to Home</Button>
            </Paper>
        </Container>
    );
  }

  // --- VIEW 2: FORM ---
  return (
    <Container sx={{ mt: 4, mb: 8 }}>
      <Typography variant="h4" gutterBottom>Checkout</Typography>
      <Grid container spacing={4}>
        <Grid item xs={12} md={7}>
            <Paper elevation={3} sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom>Shipping Information</Typography>
                <Box component="form" onSubmit={handlePlaceOrder}>
                    
                    {/* ADDRESS INPUT */}
                    <TextField 
                        label="Full Address" 
                        fullWidth 
                        multiline 
                        rows={3} 
                        sx={{ mb: 3 }} 
                        value={address} 
                        onChange={(e) => setAddress(e.target.value)} 
                        error={!!errors.address}
                        helperText={errors.address}
                    />

                    <Typography variant="h6" gutterBottom>Payment Details</Typography>
                    
                    {/* CARD NUMBER INPUT */}
                    <TextField 
                        label="Card Number" 
                        fullWidth 
                        variant="outlined" 
                        sx={{ mb: 3 }} 
                        value={cardNumber}
                        onChange={handleCardChange} // Custom Handler
                        placeholder="123456789012"
                        error={!!errors.cardNumber} // Show Red Border
                        helperText={errors.cardNumber} // Show Error Text
                        inputProps={{ maxLength: 12 }} // Hard limit
                    />
                    
                      <Grid container spacing={2}>
                        <Grid item xs={6}>
                            {/* EXPIRY INPUT */}
                            <TextField 
                                label="Expiry (MM/YY)" 
                                fullWidth 
                                placeholder="MM/YY" 
                                value={expiry}
                                onChange={handleExpiryChange} // Custom Handler
                                error={!!errors.expiry}
                                helperText={errors.expiry}
                                inputProps={{ maxLength: 5 }}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            {/* CVV INPUT */}
                            <TextField 
                                label="CVV" 
                                fullWidth 
                                placeholder="123"
                                value={cvv}
                                onChange={handleCvvChange} // Custom Handler
                                error={!!errors.cvv}
                                helperText={errors.cvv}
                                inputProps={{ maxLength: 3 }}
                            />
                        </Grid>
                      </Grid>

                      <Button type="submit" variant="contained" size="large" fullWidth sx={{ mt: 4 }}>
                        Place Order
                      </Button>
                </Box>
            </Paper>
        </Grid>

        {/* ORDER SUMMARY (No changes needed here) */}
        <Grid item xs={12} md={5}>
            <Paper elevation={3} sx={{ p: 3, bgcolor: '#f9f9f9' }}>
                <Typography variant="h6" gutterBottom>Order Summary</Typography>
                <List>
                    {cart.map((item, index) => (
                        <ListItem key={index} disableGutters>
                            <ListItemText primary={item.name} secondary={item.category} />
                            <Typography variant="body2">{item.price} TL</Typography>
                        </ListItem>
                    ))}
                    <Divider sx={{ my: 2 }} />
                    <ListItem disableGutters>
                        <ListItemText primary={<Typography variant="h6">Total</Typography>} />
                        <Typography variant="h6" color="primary">{totalPrice} TL</Typography>
                    </ListItem>
                </List>
            </Paper>
        </Grid>
      </Grid>
    </Container>
  );
}