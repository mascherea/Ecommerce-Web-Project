import { Container, Paper, Avatar, Typography, Button, Box } from "@mui/material";
import { useAuth } from "../context/AuthContext";
import LoginPage from "./MemberLogin";

export default function Profile() {
  const { user, logout } = useAuth();

  // Safety check: if no user is logged in, show the Login page
  if (!user) return <LoginPage />;

  return (
    <Container maxWidth="sm" sx={{ mt: 8 }}>
      <Paper 
        elevation={6} 
        sx={{ 
          p: 5, 
          textAlign: 'center', 
          borderRadius: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center'
        }}
      >
        {/* AVATAR DISPLAY */}
        <Avatar 
          src={user.avatar} 
          alt={user.username}
          sx={{ 
            width: 120, 
            height: 120, 
            mb: 3, 
            border: '4px solid #fff',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            bgcolor: '#bdbdbd' // Gray fallback color if image fails
          }}
        />

        {/* WELCOME MESSAGE */}
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Hello, {user.username}!
        </Typography>

        <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
          {user.email}
        </Typography>

        {/* LOGOUT BUTTON */}
        <Button 
          variant="outlined" 
          color="error" 
          onClick={logout} 
          size="large"
          sx={{ 
            px: 4, 
            borderRadius: 20, 
            textTransform: 'none',
            fontWeight: 'bold'
          }}
        >
          Logout
        </Button>
      </Paper>
    </Container>
  );
}