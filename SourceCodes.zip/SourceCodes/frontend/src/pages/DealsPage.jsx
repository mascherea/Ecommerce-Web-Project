import { useEffect, useState } from 'react';
import { Container, Typography, Grid, Box, Alert } from '@mui/material';
import ProductCard from '../components/ProductCard';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';

export default function DealsPage() {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8080/api/products')
            .then(res => res.json())
            .then(data => {
                // Filter specifically for items we want on "Sale" (e.g., Protein & Gainers)
                const saleItems = data.filter(p => 
                    p.category === 'Protein Powder' || p.category === 'Mass Gainer'
                );
                setProducts(saleItems);
            })
            .catch(err => console.error("Error fetching deals:", err));
    }, []);

    return (
        <Container maxWidth="xl" sx={{ mt: 4, mb: 8 }}>
            
            {/* Header Banner */}
            <Box sx={{ 
                bgcolor: '#d32f2f', // Red background for urgency
                color: 'white', 
                p: 4, 
                borderRadius: 4, 
                mb: 6, 
                textAlign: 'center',
                boxShadow: 3
            }}>
                <LocalOfferIcon sx={{ fontSize: 60, mb: 1 }} />
                <Typography variant="h3" fontWeight="900" textTransform="uppercase">
                    Flash Sale
                </Typography>
                <Typography variant="h6">
                    Up to 20% OFF on select Protein & Mass Gainers. Limited time only!
                </Typography>
            </Box>

            {products.length === 0 ? (
                <Alert severity="info">Loading huge deals...</Alert>
            ) : (
                <Grid container spacing={3}>
                    {products.map((product) => (
                        <Grid item key={product.id} xs={12} sm={6} md={4} lg={3}>
                            {/* MAGIC TRICK: 
                                We pass 'originalPrice' calculated as 20% higher than the current price.
                                This creates the illusion of a discount without changing the database.
                            */}
                            <ProductCard 
                                product={product} 
                                originalPrice={product.price * 1.2} 
                            />
                        </Grid>
                    ))}
                </Grid>
            )}
        </Container>
    );
}