import {
  Typography,
  Card,
  CardContent,
  CardMedia,
  Button,
  Grid,
  Divider,
  Box,
  Container
} from "@mui/material";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom"; // 1. Import useNavigate

export default function Cart() {
  const { cart, removeFromCart } = useCart(); // Removed 'total' if it's not in your context, otherwise keep it
  const navigate = useNavigate(); // 2. Initialize the hook

  // Calculate total manually if your Context doesn't provide it directly
  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

  if (cart.length === 0) {
    return (
      <Container sx={{ mt: 10, textAlign: 'center' }}>
        <Typography variant="h5">
          Your cart is empty
        </Typography>
        <Button variant="contained" sx={{ mt: 2 }} onClick={() => navigate("/")}>
          Start Shopping
        </Button>
      </Container>
    );
  }

  return (
    <Container sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>Cart</Typography>

      <Grid container spacing={3}>
        {/* ITEMS */}
        <Grid item xs={12} md={8}>
          {cart.map(item => (
            <Card
              key={item.id}
              sx={{
                display: "flex",
                mb: 2,
                backgroundColor: "#fafafa"
              }}
            >
              <CardMedia
                component="img"
                image={item.imageUrl}
                sx={{
                  width: 140,
                  objectFit: "contain",
                  p: 1,
                  backgroundColor: "#fff"
                }}
              />

              <CardContent sx={{ flex: 1 }}>
                <Typography variant="h6">{item.name}</Typography>
                <Typography>Price: {item.price} TL</Typography>
                {/* If you have quantity logic, use item.qty, otherwise just 1 */}
                <Typography>Qty: 1</Typography> 

                <Button
                  color="error"
                  sx={{ mt: 1 }}
                  onClick={() => removeFromCart(item.id)}
                >
                  Remove
                </Button>
              </CardContent>
            </Card>
          ))}
        </Grid>

        {/* SUMMARY */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Order Summary</Typography>
              <Divider sx={{ my: 2 }} />
              <Box display="flex" justifyContent="space-between">
                <Typography>Total</Typography>
                <Typography variant="h6" color="primary">
                    {totalPrice} TL
                </Typography>
              </Box>
              
              {/* 3. The Update: Navigate to Checkout */}
              <Button 
                fullWidth 
                variant="contained" 
                size="large"
                sx={{ mt: 2 }}
                onClick={() => navigate("/checkout")}
              >
                Proceed to Checkout
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}