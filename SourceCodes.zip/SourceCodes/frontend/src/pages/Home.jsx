import { useEffect, useState, useRef } from 'react';
import { Container, Typography, Box, IconButton, Button, Grid, Paper, Avatar, useTheme } from '@mui/material';
import { Link } from 'react-router-dom';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';

// --- NEW IMPORTS FOR CATEGORY ICONS ---
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter'; // Protein
import BoltIcon from '@mui/icons-material/Bolt';                   // Creatine
import ScienceIcon from '@mui/icons-material/Science';             // BCAA
import ScaleIcon from '@mui/icons-material/Scale';                 // Mass Gainer

import ProductCard from '../components/ProductCard';

// --- ICON MAPPING ---
// This maps your backend category names to Material UI Icons
const categoryIcons = {
  "Protein Powder": <FitnessCenterIcon sx={{ fontSize: 32 }} />,
  "Creatine": <BoltIcon sx={{ fontSize: 32 }} />,
  "BCAA": <ScienceIcon sx={{ fontSize: 32 }} />,
  "Mass Gainer": <ScaleIcon sx={{ fontSize: 32 }} />
};

// --- HERO SECTION ---
const HeroSection = () => (
  <Box 
    sx={{ 
      position: 'relative',
      height: { xs: '400px', md: '600px' },
      backgroundImage: 'url("https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'white',
      mb: 6,
      boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
    }}
  >
    <Box sx={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', background: 'linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.8) 100%)' }} />
    <Box sx={{ position: 'relative', textAlign: 'center', zIndex: 1, px: 2, maxWidth: '800px' }}>
        <Typography variant="h2" fontWeight="900" sx={{ letterSpacing: '-2px', mb: 2, textTransform: 'uppercase', fontSize: { xs: '2.5rem', md: '4rem' } }}>
            Unleash Your Potential
        </Typography>
        <Typography variant="h6" sx={{ mb: 5, fontWeight: 300, fontSize: { xs: '1rem', md: '1.25rem' }, color: '#f0f0f0' }}>
            Elite supplements scientifically formulated for power, endurance, and rapid recovery.
        </Typography>
        <Button component={Link} to="/best-sellers" variant="contained" size="large" color="primary" sx={{ borderRadius: '50px', px: 6, py: 2, fontSize: '1.1rem', fontWeight: 'bold' }}>
            Shop Best Sellers
        </Button>
    </Box>
  </Box>
);

// --- NEW CATEGORY CIRCLES SECTION (Replaces Image Links) ---
const CategoryNav = () => {
    const theme = useTheme();
    // Static list of categories (or you can fetch this if you prefer)
    const categories = [
        { name: "Protein Powder", link: "Protein Powder" },
        { name: "Creatine", link: "Creatine" },
        { name: "BCAA", link: "BCAA" },
        { name: "Mass Gainer", link: "Mass Gainer" }
    ];

    return (
        <Container sx={{ mb: 8 }}>
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: { xs: 3, md: 8 }, flexWrap: 'wrap' }}>
                {categories.map((cat, index) => (
                    <Box 
                        key={index} 
                        component={Link}
                        to={`/category/${cat.link}`}
                        sx={{ 
                            display: 'flex', 
                            flexDirection: 'column', 
                            alignItems: 'center', 
                            textDecoration: 'none',
                            group: 'true', // for hover effects
                            cursor: 'pointer'
                        }}
                    >
                        <Avatar sx={{ 
                            width: { xs: 60, md: 80 }, 
                            height: { xs: 60, md: 80 }, 
                            mb: 2,
                            // SMART COLORS: Dark background in Dark Mode, Light in Light Mode
                            bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.05)' : 'white',
                            color: theme.palette.mode === 'dark' ? 'primary.main' : 'grey.800',
                            border: '1px solid',
                            borderColor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.1)' : 'grey.300',
                            transition: 'all 0.3s ease',
                            boxShadow: 3,
                            '&:hover': { 
                                transform: 'translateY(-5px)', 
                                boxShadow: 6,
                                borderColor: 'primary.main',
                                color: 'primary.main'
                            }
                        }}>
                            {categoryIcons[cat.name] || <FitnessCenterIcon />}
                        </Avatar>
                        <Typography variant="body1" fontWeight="bold" color="text.primary">
                            {cat.name}
                        </Typography>
                    </Box>
                ))}
            </Box>
        </Container>
    );
};

// --- FEATURES SECTION ---
const FeaturesSection = () => {
    const theme = useTheme(); 
    return (
        <Container sx={{ mb: 10 }}>
            <Grid container spacing={4} justifyContent="center">
                {[
                    { icon: <LocalShippingIcon sx={{ fontSize: 40 }} />, title: "Free Fast Shipping", desc: "Orders over 500 TL" },
                    { icon: <VerifiedUserIcon sx={{ fontSize: 40 }} />, title: "100% Authentic", desc: "Certified Original" },
                    { icon: <SupportAgentIcon sx={{ fontSize: 40 }} />, title: "24/7 Support", desc: "Expert Guidance" }
                ].map((feature, index) => (
                    <Grid item xs={12} md={4} key={index}>
                        <Paper elevation={0} sx={{ 
                            p: 4, textAlign: 'center', 
                            bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.05)' : 'white', 
                            border: '1px solid',
                            borderColor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.1)' : '#e0e0e0',
                            borderRadius: 4,
                            transition: '0.3s',
                            '&:hover': { transform: 'translateY(-5px)', boxShadow: 6 }
                        }}>
                            <Box sx={{ color: 'primary.main', mb: 2 }}>{feature.icon}</Box>
                            <Typography variant="h6" fontWeight="bold" gutterBottom color="text.primary">{feature.title}</Typography>
                            <Typography variant="body2" color="text.secondary">{feature.desc}</Typography>
                        </Paper>
                    </Grid>
                ))}
            </Grid>
        </Container>
    );
};

// --- PROMO BANNER ---
const PromoBanner = () => (
    <Box sx={{ 
        my: 10, py: 8, 
        bgcolor: '#111', color: 'white', textAlign: 'center',
        backgroundImage: 'linear-gradient(45deg, #1a1a1a 25%, transparent 25%, transparent 75%, #1a1a1a 75%, #1a1a1a), linear-gradient(45deg, #1a1a1a 25%, transparent 25%, transparent 75%, #1a1a1a 75%, #1a1a1a)',
        backgroundSize: '20px 20px', backgroundPosition: '0 0, 10px 10px',
        borderTop: '1px solid #333', borderBottom: '1px solid #333'
    }}>
        <Container>
            <Typography variant="overline" color="warning.main" fontWeight="bold" letterSpacing={2}>LIMITED TIME OFFER</Typography>
            <Typography variant="h3" fontWeight="900" sx={{ mb: 2, textTransform: 'uppercase' }}>Summer Shred Sale</Typography>
            <Typography variant="h6" sx={{ mb: 4, color: '#aaa', maxWidth: '600px', mx: 'auto' }}>
                Get up to 30% off on all Fat Burners and Whey Isolate.
            </Typography>
            <Button component={Link} to="/deals" variant="contained" color="warning" size="large" sx={{ px: 5, py: 1.5, fontWeight: 'bold' }}>
                View Exclusive Deals
            </Button>
        </Container>
    </Box>
);

// --- CATEGORY PRODUCT ROW SECTION ---
const CategorySection = ({ title, linkCategory, products, onAddReview }) => {
    const scrollRef = useRef(null);
    const theme = useTheme();

    const scroll = (offset) => {
        if (scrollRef.current) scrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    };

    return (
        <Container maxWidth="xl" sx={{ mb: 8, position: 'relative' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'end', mb: 3, px: 1 }}>
                <Typography variant="h4" fontWeight="800" sx={{ color: 'text.primary', letterSpacing: '-0.5px' }}>
                    {title}
                </Typography>
                <Button component={Link} to={`/category/${linkCategory}`} color="primary" sx={{ fontWeight: 'bold' }}>
                    See All
                </Button>
            </Box>

            <Box sx={{ position: 'relative' }}>
                <IconButton 
                    onClick={() => scroll(-350)}
                    sx={{ position: 'absolute', left: -20, top: '50%', transform: 'translateY(-50%)', zIndex: 2, bgcolor: 'background.paper', boxShadow: 3, '&:hover': { bgcolor: 'action.hover' }, display: { xs: 'none', md: 'flex' } }}
                >
                    <ArrowBackIosNewIcon fontSize="small" />
                </IconButton>

                <Box
                    ref={scrollRef}
                    sx={{
                        display: 'flex', gap: 3, overflowX: 'auto', scrollBehavior: 'smooth', py: 2, px: 1,
                        '&::-webkit-scrollbar': { display: 'none' }, scrollbarWidth: 'none',
                    }}
                >
                    {products.map((product) => (
                        <Box key={product.id} sx={{ minWidth: { xs: 260, md: 300 } }}> 
                            <ProductCard product={product} onAddReview={onAddReview} />
                        </Box>
                    ))}
                </Box>

                <IconButton 
                    onClick={() => scroll(350)}
                    sx={{ position: 'absolute', right: -20, top: '50%', transform: 'translateY(-50%)', zIndex: 2, bgcolor: 'background.paper', boxShadow: 3, '&:hover': { bgcolor: 'action.hover' }, display: { xs: 'none', md: 'flex' } }}
                >
                    <ArrowForwardIosIcon fontSize="small" />
                </IconButton>
            </Box>
        </Container>
    );
};

// --- MAIN PAGE COMPONENT ---
export default function Home() {
    const [products, setProducts] = useState([]);
    const theme = useTheme();

    useEffect(() => {
        fetch('http://localhost:8080/api/products')
            .then(res => res.json())
            .then(data => setProducts(data))
            .catch(err => console.error("Error fetching products:", err));
    }, []);

    const handleAddReview = (productId) => {
        fetch(`http://localhost:8080/api/products/${productId}/review`, { method: 'POST' })
            .then(response => { if (response.ok) return response.json(); throw new Error('Failed'); })
            .then(updatedProduct => setProducts(prev => prev.map(p => p.id === productId ? updatedProduct : p)))
            .catch(err => console.error(err));
    };

    const getProductsByCategory = (cat) => products.filter(p => p.category === cat);

    // BACKGROUND STYLES
    const lightModeBg = {
        background: 'linear-gradient(180deg, #f0f2f5 0%, #e0e4e8 100%)',
    };

    const darkModeBg = {
        backgroundColor: '#121212',
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)',
        backgroundSize: '30px 30px'
    };

    return (
        <Box sx={{ 
            pb: 8, 
            minHeight: '100vh',
            transition: 'background 0.3s ease',
            ...(theme.palette.mode === 'dark' ? darkModeBg : lightModeBg)
        }}>
            <HeroSection />
            
            {/* Added the new CategoryNav here */}
            <CategoryNav />
            
            <FeaturesSection />
            
            {getProductsByCategory('Protein Powder').length > 0 && 
                <CategorySection title="Protein Powders" linkCategory="Protein Powder" products={getProductsByCategory('Protein Powder')} onAddReview={handleAddReview} />
            }
            
            <PromoBanner />
            
            {getProductsByCategory('Creatine').length > 0 && 
                <CategorySection title="Creatine Essentials" linkCategory="Creatine" products={getProductsByCategory('Creatine')} onAddReview={handleAddReview} />
            }
            {getProductsByCategory('BCAA').length > 0 && 
                <CategorySection title="BCAA Recovery" linkCategory="BCAA" products={getProductsByCategory('BCAA')} onAddReview={handleAddReview} />
            }
            {getProductsByCategory('Mass Gainer').length > 0 && 
                <CategorySection title="Mass Gainers" linkCategory="Mass Gainer" products={getProductsByCategory('Mass Gainer')} onAddReview={handleAddReview} />
            }
        </Box>
    );
}