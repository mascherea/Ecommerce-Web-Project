  import { useEffect, useState } from "react";
import { Container, Grid, Card, CardMedia, CardContent, Typography, Button, Box, Chip } from "@mui/material";
import { Star, LocalFireDepartment } from "@mui/icons-material"; // Cool icons
import { useCart } from "../context/CartContext";

// Helper function to fetch data (or import your existing api function)
const fetchAllProducts = async () => {
  const response = await fetch("http://localhost:8080/api/products");
  return response.json();
};

export default function BestSellersPage() {
  const [products, setProducts] = useState([]);
  const { addToCart } = useCart();

  useEffect(() => {
    fetchAllProducts().then(data => {
      // SORT LOGIC: High reviews first
      const sorted = data.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
      setProducts(sorted);
    });
  }, []);

  return (
    <Container sx={{ mt: 4, mb: 8 }}>
      
      {/* HEADER SECTION */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" fontWeight="bold" gutterBottom>
           Best Selling Supplements <LocalFireDepartment color="error" fontSize="large"/>
        </Typography>
        <Typography variant="h6" color="text.secondary">
          Our most popular products based on customer reviews.
        </Typography>
      </Box>

      {/* PRODUCTS GRID */}
      <Grid container spacing={4}>
        {products.map((product, index) => (
          <Grid item key={product.id} xs={12} sm={6} md={4}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', position: 'relative' }}>
              
              {/* TOP 3 BADGE (Gold/Silver/Bronze) */}
              {index < 3 && (
                <Chip 
                  label={`#${index + 1} Best Seller`} 
                  color={index === 0 ? "warning" : "default"} // Gold for #1
                  sx={{ 
                    position: 'absolute', 
                    top: 10, 
                    right: 10, 
                    fontWeight: 'bold',
                    backgroundColor: index === 0 ? '#ffbf00' : (index === 1 ? '#C0C0C0' : '#CD7F32'),
                    color: '#fff'
                  }} 
                />
              )}

              <CardMedia
                component="img"
                height="250"
                image={product.imageUrl || "https://via.placeholder.com/200"}
                alt={product.name}
                sx={{ objectFit: "contain", p: 2 }}
              />
              
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography gutterBottom variant="h5" component="div" fontWeight="bold">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {product.category}
                </Typography>
                
                {/* REVIEW COUNT DISPLAY */}
                <Box display="flex" alignItems="center" sx={{ mb: 2 }}>
                    <Star sx={{ color: '#faaf00', mr: 0.5 }} />
                    <Typography variant="body2" fontWeight="bold">
                        {product.reviewCount} Reviews
                    </Typography>
                </Box>

                <Typography variant="h6" color="primary" sx={{ mb: 2 }}>
                  {product.price} TL
                </Typography>

                <Button 
                  variant="contained" 
                  fullWidth 
                  size="large"
                  onClick={() => addToCart(product)}
                >
                  Add to Cart
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}