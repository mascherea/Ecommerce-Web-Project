import { useState } from "react";
import { 
    Container, Paper, TextField, Button, Typography, Box, 
    Avatar, Radio, RadioGroup, FormControlLabel, FormControl, 
    FormLabel, Fade 
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

// --- CONFIGURATION ---
// TRY THIS URL INSTEAD (Wikipedia allows all hotlinking):
const ADMIN_DEFAULT_URL = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png"; 
// The fallback:
const DEFAULT_AVATAR = "https://media.tenor.com/qELs1-cyr8sAAAAe/ash-child.png";

export default function RegisterPage() {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({ username: "", email: "", password: "" });
  const [avatarMode, setAvatarMode] = useState('default'); 
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [imgError, setImgError] = useState(false); 

  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCustomUrlChange = (e) => {
    setCustomAvatarUrl(e.target.value);
    setImgError(false); 
  };

  // --- PREVIEW LOGIC ---
  const getAvatarPreview = () => {
    if (avatarMode === 'admin') return ADMIN_DEFAULT_URL;
    
    if (avatarMode === 'custom' && customAvatarUrl) {
        if (imgError) return DEFAULT_AVATAR;
        return customAvatarUrl;
    }
    return DEFAULT_AVATAR;
  };

  const previewSrc = getAvatarPreview();

  // --- DEBUG HANDLERS ---
  const handleImageError = () => {
    console.error("🚨 PREVIEW FAILED!");
    console.error("❌ Broken URL:", previewSrc);
    // If it was the Admin image failing, we don't set imgError (because user can't fix it), 
    // but the UI will likely stay broken or show default if we added logic for it.
    // For Custom images, we trigger the swap:
    if (avatarMode === 'custom') {
        setImgError(true);
    }
  };

  const handleImageSuccess = () => {
    console.log("✅ Preview Loaded Successfully:", previewSrc);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setSuccessMessage(""); 

    let finalAvatarUrl = DEFAULT_AVATAR;

    if (avatarMode === 'admin') {
        finalAvatarUrl = ADMIN_DEFAULT_URL;
    } else if (avatarMode === 'custom' && customAvatarUrl && !imgError) {
        finalAvatarUrl = customAvatarUrl;
    }

    // --- DEBUG: Show exactly what is being sent ---
    console.log("🚀 REGISTERING USER WITH AVATAR:", finalAvatarUrl);

    const payload = {
        ...formData,
        avatar: finalAvatarUrl 
    };

    try {
      const response = await fetch("http://localhost:8080/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        setSuccessMessage("Registration Successful! You can now login.");
        setFormData(null); 
      } else {
        const text = await response.text();
        setError(text);
      }
    } catch (err) {
      setError("Something went wrong. Is the backend running?");
    }
  };

  return (
    <Container maxWidth="xs" sx={{ mt: 4, mb: 4 }}>
      <Paper elevation={3} sx={{ p: 4, textAlign: 'center' }}>
        
        {/* AVATAR PREVIEW */}
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 2 }}>
            <Avatar 
                src={previewSrc}
                // DEBUGGING & FIX ADDED HERE
                slotProps={{ 
                    img: { 
                        onError: handleImageError,
                        onLoad: handleImageSuccess,
                        referrerPolicy: "no-referrer" // Try to bypass blocking
                    }
                }}
                sx={{ 
                    width: 100, 
                    height: 100, 
                    border: '4px solid #f0f0f0',
                    bgcolor: 'transparent', 
                    mb: 1
                }}
            />
            {avatarMode === 'custom' && imgError && customAvatarUrl.length > 5 && (
                <Typography variant="caption" color="error">
                    Invalid Image URL. Using default.
                </Typography>
            )}
        </Box>

        <Typography variant="h5" gutterBottom fontWeight="bold">Create Account</Typography>
        
        {error && <Typography color="error" sx={{ mb: 2 }}>{error}</Typography>}
        {successMessage && <Typography color="primary" variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>{successMessage}</Typography>}

        {formData && (
          <Box component="form" onSubmit={handleRegister}>
            <TextField 
              label="Username" name="username" fullWidth required sx={{ mb: 2 }} 
              onChange={handleChange} 
            />
            <TextField 
              label="Email" name="email" type="email" fullWidth required sx={{ mb: 2 }} 
              onChange={handleChange} 
            />
            <TextField 
              label="Password" name="password" type="password" fullWidth required sx={{ mb: 3 }} 
              onChange={handleChange} 
            />
            
            <Paper variant="outlined" sx={{ p: 2, mb: 3, bgcolor: '#fafafa', textAlign: 'left' }}>
                <FormControl component="fieldset">
                    <FormLabel component="legend" sx={{ fontSize: '0.9rem', mb: 1, fontWeight: 'bold' }}>
                        Profile Picture
                    </FormLabel>
                    <RadioGroup
                        value={avatarMode}
                        onChange={(e) => setAvatarMode(e.target.value)}
                    >
                        <FormControlLabel 
                            value="default" 
                            control={<Radio size="small" />} 
                            label={
                                <Box display="flex" alignItems="center">
                                    <Typography variant="body2" sx={{ mr: 1 }}>Default Avatar</Typography>
                                    <AccountCircleIcon fontSize="inherit" color="action" />
                                </Box>
                            } 
                        />
                        
                        <FormControlLabel 
                            value="custom" 
                            control={<Radio size="small" />} 
                            label={<Typography variant="body2">Custom Image URL</Typography>} 
                        />
                        {avatarMode === 'custom' && (
                            <Fade in={true}>
                                <Box sx={{ pl: 4, pr: 1, pb: 1 }}>
                                    <TextField
                                        fullWidth
                                        size="small"
                                        placeholder="https://example.com/me.jpg"
                                        value={customAvatarUrl}
                                        onChange={handleCustomUrlChange}
                                        error={imgError && customAvatarUrl.length > 0}
                                        sx={{ bgcolor: 'white' }}
                                    />
                                </Box>
                            </Fade>
                        )}

                        <FormControlLabel 
                            value="admin" 
                            control={<Radio size="small" />} 
                            label={
                                <Box display="flex" alignItems="center">
                                    <Typography variant="body2" sx={{ mr: 1 }}>Let Admin Choose</Typography>
                                    <AdminPanelSettingsIcon fontSize="inherit" color="action" />
                                </Box>
                            } 
                        />
                    </RadioGroup>
                </FormControl>
            </Paper>

            <Button type="submit" variant="contained" fullWidth size="large" sx={{ bgcolor: '#1a1a1a', '&:hover': { bgcolor: '#333' } }}>
              Register
            </Button>
          </Box>
        )}

        <Button sx={{ mt: 2 }} onClick={() => navigate("/login")}>
          {successMessage ? "Go to Login Page" : "Already have an account? Login"}
        </Button>
      </Paper>
    </Container>
  );
}