import { createContext, useContext, useState } from "react";

const CartContext = createContext();

export function useCart() {
  return useContext(CartContext);
}

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);

  // Add item to cart
  const addToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
  };

  // Remove item from cart
  const removeFromCart = (id) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id));
  };

  // --- NEW FUNCTION: CLEAR CART ---
  const clearCart = () => {
    setCart([]); // This empties the array
  };

  // Calculate total price (Optional helper)
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    // --- ADD clearCart TO THE VALUE BELOW ---
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart, total }}>
      {children}
    </CartContext.Provider>
  );
}