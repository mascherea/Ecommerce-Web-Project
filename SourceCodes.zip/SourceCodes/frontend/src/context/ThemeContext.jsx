import { createContext, useState, useMemo, useContext } from 'react';
import { createTheme, ThemeProvider as MUIThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

const ColorModeContext = createContext({ toggleColorMode: () => {} });

export const useColorMode = () => useContext(ColorModeContext);

export const ThemeProvider = ({ children }) => {
  const [mode, setMode] = useState('light'); // Default to Light (Premium Silver)

  const colorMode = useMemo(() => ({
    toggleColorMode: () => {
      setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
    },
  }), []);

  const theme = useMemo(() => createTheme({
    palette: {
      mode,
      ...(mode === 'light'
        ? {
            // LIGHT MODE COLORS (Premium Silver)
            background: {
              default: '#f0f2f5', 
              paper: '#ffffff',
            },
            text: { primary: '#1a1a1a', secondary: '#555555' },
          }
        : {
            // DARK MODE COLORS (Aggressive Gym)
            primary: { main: '#29b6f6' }, // Brighter blue for dark mode
            background: {
              default: '#121212',
              paper: '#1e1e1e',
            },
            text: { primary: '#ffffff', secondary: '#b0b0b0' },
          }),
    },
  }), [mode]);

  return (
    <ColorModeContext.Provider value={colorMode}>
      <MUIThemeProvider theme={theme}>
        {/* CssBaseline kicks in the default background color immediately */}
        <CssBaseline /> 
        {children}
      </MUIThemeProvider>
    </ColorModeContext.Provider>
  );
};