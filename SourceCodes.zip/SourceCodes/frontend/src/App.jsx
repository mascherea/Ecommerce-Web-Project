import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./layout/Layout";
import Home from "./pages/Home";
import CategoryPage from "./pages/CategoryPage";
import Cart from "./pages/Cart";
import Profile from "./pages/Profile";
import SearchPage from "./pages/SearchPage";
import LoginPage from "./pages/MemberLogin"; 
import CheckoutPage from "./pages/CheckoutPage"; 
import BestSellersPage from "./pages/BestSellersPage";
import RegisterPage from "./pages/RegisterPage";
import DealsPage from "./pages/DealsPage";

// Contexts
import { CartProvider } from "./context/CartContext";
import { AuthProvider } from "./context/AuthContext";
import { ThemeProvider } from "./context/ThemeContext"; // <--- IMPORT THIS

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        {/* WRAP EVERYTHING IN THEME PROVIDER */}
        <ThemeProvider> 
          <BrowserRouter>
            <Routes>
              <Route element={<Layout />}>
                <Route path="/" element={<Home />} />
                <Route path="/category/:name" element={<CategoryPage />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/best-sellers" element={<BestSellersPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route path="/deals" element={<DealsPage />} /> 
              </Route>
            </Routes>
          </BrowserRouter>
        </ThemeProvider>
      </CartProvider>
    </AuthProvider>
  );
}
export default App;