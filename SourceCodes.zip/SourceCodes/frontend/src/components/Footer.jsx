import { Box, Container, Grid, Typography, Link } from "@mui/material";
import { Email, Phone, FitnessCenter } from "@mui/icons-material";

export default function Footer() {
  return (
    <Box
      component="footer"
      sx={{
        py: 3,
        px: 2,
        mt: 'auto', // This pushes the footer to the bottom
        backgroundColor: (theme) =>
          theme.palette.mode === "light"
            ? theme.palette.grey[200]
            : theme.palette.grey[800],
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          
          {/* COMPANY INFO */}
          <Grid item xs={12} sm={6}>
            <Box display="flex" alignItems="center" gap={1} mb={1}>
                <FitnessCenter color="primary" />
                <Typography variant="h6" color="text.primary">
                Gym Supplements
                </Typography>
            </Box>
            <Typography variant="body2" color="text.secondary">
              Est. 2023
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Premium quality supplements for your daily workout needs. 
              Fuel your gains with the best ingredients on the market.
            </Typography>
          </Grid>

          {/* CONTACT INFO */}
          <Grid item xs={12} sm={6}>
            <Typography variant="h6" color="text.primary" gutterBottom>
              Contact Us
            </Typography>
            
            <Box display="flex" alignItems="center" gap={1} mb={1}>
              <Email color="action" fontSize="small" />
              <Link href="mailto:support@gymsupplements.com" color="inherit" underline="hover">
                support@gymsupplements.com
              </Link>
            </Box>

            <Box display="flex" alignItems="center" gap={1}>
              <Phone color="action" fontSize="small" />
              <Typography variant="body2" color="text.primary">
                +90 555 123 45 67
              </Typography>
            </Box>
          </Grid>

        </Grid>

        {/* COPYRIGHT */}
        <Box mt={3} textAlign="center">
          <Typography variant="caption" color="text.secondary">
            © {new Date().getFullYear()} Gym Supplements. All rights reserved.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
}