import { Card, CardContent, CardMedia, Typography, Button, Box, IconButton, Chip } from "@mui/material";
import { Star } from "@mui/icons-material";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

// Added 'originalPrice' prop
export default function ProductCard({ product, isBestSeller, onAddReview, originalPrice }) {
  const { addToCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const reviewCount = product.reviewCount || 0; 
  const stock = product.stock !== undefined ? product.stock : 50; // Default to 50 if missing
  const isOutOfStock = stock === 0;
  const isLowStock = stock > 0 && stock < 10;

  const handleAddToCart = () => {
    if (user) {
      addToCart(product);
    } else {
      navigate("/login", { state: { productToAdd: product } });
    }
  };

  return (
    <Card 
      sx={{ 
        width: '100%', 
        height: '100%', 
        display: 'flex', 
        flexDirection: 'column',
        justifyContent: 'space-between',
        position: 'relative',
        transition: "0.3s",
        "&:hover": { transform: "translateY(-5px)", boxShadow: 6 },
        opacity: isOutOfStock ? 0.7 : 1
      }}
    >
      {/* BADGES */}
      {isBestSeller && (
        <Chip label="Best Seller" color="warning" size="small" sx={{ position: 'absolute', top: 10, left: 10, zIndex: 1, fontWeight: 'bold' }} />
      )}
      
      {/* SHOW DEAL BADGE IF ORIGINAL PRICE EXISTS */}
      {originalPrice && !isOutOfStock && (
        <Chip 
            label="SAVE 20%" 
            color="error" 
            size="small" 
            sx={{ position: 'absolute', top: 10, left: isBestSeller ? 100 : 10, zIndex: 1, fontWeight: 'bold' }} 
        />
      )}

      {/* STOCK BADGE */}
      {isOutOfStock ? (
         <Chip label="Out of Stock" color="error" size="small" sx={{ position: 'absolute', top: 10, right: 10, zIndex: 1 }} />
      ) : isLowStock ? (
         <Chip label={`Low Stock: ${stock} left`} color="error" variant="outlined" size="small" sx={{ position: 'absolute', top: 10, right: 10, zIndex: 1, bgcolor: 'white' }} />
      ) : null}

      <Box sx={{ height: 250, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', p: 2 }}>
        <CardMedia 
            component="img" 
            image={product.imageUrl} 
            alt={product.name} 
            sx={{ maxHeight: '100%', maxWidth: '100%', objectFit: "contain", filter: isOutOfStock ? "grayscale(100%)" : "none" }} 
        />
      </Box>
      
      <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
        <Typography variant="caption" color="text.secondary">{product.category}</Typography>
        
        <Typography 
            gutterBottom variant="h6" component="div" title={product.name}
            sx={{ width: '100%', fontSize: '1rem', fontWeight: 'bold', height: '42px', lineHeight: '1.2', overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', mb: 1 }}
        >
          {product.name}
        </Typography>

        <Box display="flex" alignItems="center" mb={1}>
            <IconButton onClick={() => onAddReview && onAddReview(product.id)} color="warning" size="small" sx={{ p: 0, mr: 0.5 }}>
                <Star fontSize="small" />
            </IconButton>
            <Typography variant="caption" color="text.secondary">({reviewCount} reviews)</Typography>
        </Box>

        {/* PRICE SECTION UPDATED */}
        <Box sx={{ mt: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box>
                {originalPrice ? (
                    <>
                        <Typography variant="caption" sx={{ textDecoration: 'line-through', color: 'text.secondary', display: 'block' }}>
                            {originalPrice.toFixed(2)} TL
                        </Typography>
                        <Typography variant="h6" color="error.main" fontWeight="bold">
                            {product.price} TL
                        </Typography>
                    </>
                ) : (
                    <Typography variant="h6" color="primary">
                        {product.price} TL
                    </Typography>
                )}
            </Box>
            
            <Button 
                size="small" 
                variant="contained" 
                onClick={handleAddToCart}
                disabled={isOutOfStock}
                color={isOutOfStock ? "inherit" : (originalPrice ? "error" : "primary")} // Red button for deals
            >
                {isOutOfStock ? "Sold Out" : "Add"}
            </Button>
        </Box>
      </CardContent>
    </Card>
  );
}