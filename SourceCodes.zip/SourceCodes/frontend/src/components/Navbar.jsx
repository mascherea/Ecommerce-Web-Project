import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  InputBase,
  Badge,
  Box,
  IconButton,
  Avatar
} from "@mui/material";
import { 
    Search as SearchIcon, 
    ShoppingCart, 
    Person,
    Brightness4 as Brightness4Icon, // Moon Icon
    Brightness7 as Brightness7Icon  // Sun Icon
} from "@mui/icons-material";
import { Link, useNavigate } from "react-router-dom";
import { styled, alpha, useTheme } from "@mui/material/styles"; // Added useTheme
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { useColorMode } from "../context/ThemeContext"; // Import your Theme Hook
import { useState } from "react";

// =====================
// STYLED COMPONENTS
// =====================
const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": { backgroundColor: alpha(theme.palette.common.white, 0.25) },
  marginRight: theme.spacing(2),
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto"
  }
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  display: "flex",
  alignItems: "center",
  justifyContent: "center"
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: { width: "40ch" }
  }
}));

// =====================
// MAIN COMPONENT
// =====================
export default function Navbar() {
  const { cart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");

  // Theme Hooks
  const theme = useTheme();
  const { toggleColorMode } = useColorMode();

  const handleSearch = (e) => {
    if (e.key === "Enter" && searchTerm.trim()) {
      navigate(`/search?q=${searchTerm}`);
      setSearchTerm("");
    }
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{ 
          borderBottom: "1px solid",
          borderColor: "divider", // Uses theme border color automatically
          bgcolor: "background.paper", // Adapt to dark/light mode
          color: "text.primary" 
      }}
    >
      <Toolbar>

        {/* LOGO + BRAND */}
        <Box sx={{ display: "flex", alignItems: "center", mr: 3 }}>
          <Link
            to="/best-sellers"
            style={{
              display: "flex",
              alignItems: "center",
              textDecoration: "none"
            }}
          >
            <img
              src="https://cdn-icons-png.flaticon.com/512/2964/2964514.png"
              alt="Best Sellers"
              style={{
                width: 40,
                height: 40,
                marginRight: 10,
                cursor: "pointer"
              }}
            />
          </Link>

          <Typography
            variant="h6"
            component={Link}
            to="/"
            sx={{
              textDecoration: "none",
              color: "inherit",
              fontWeight: "bold"
            }}
          >
            RECATHLON
          </Typography>
        </Box>

        {/* SEARCH BAR */}
        <Search sx={{ bgcolor: alpha(theme.palette.text.primary, 0.05), '&:hover': { bgcolor: alpha(theme.palette.text.primary, 0.1) } }}>
          <SearchIconWrapper>
            <SearchIcon />
          </SearchIconWrapper>
          <StyledInputBase
            placeholder="Search for supplements..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleSearch}
          />
        </Search>

        <Box sx={{ flexGrow: 1 }} />

        {/* RIGHT SIDE ICONS */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>

          {/* THEME TOGGLE BUTTON (NEW) */}
          <IconButton onClick={toggleColorMode} color="inherit">
            {theme.palette.mode === 'dark' ? <Brightness7Icon /> : <Brightness4Icon />}
          </IconButton>

          {/* PROFILE BUTTON */}
          <Button
            color="inherit"
            component={Link}
            to={user ? "/profile" : "/login"}
            sx={{ textTransform: "none" }}
          >
            {user ? (
              <Box display="flex" alignItems="center" gap={1}>
                <Avatar
                  src={user?.avatar || ""}
                  alt={user?.username || "User"}
                  sx={{
                    width: 32,
                    height: 32,
                    border: "1px solid",
                    borderColor: "text.primary"
                  }}
                />
                <Typography variant="body1" fontWeight="bold">
                  {user?.username || "Profile"}
                </Typography>
              </Box>
            ) : (
              <Box display="flex" alignItems="center" gap={1}>
                <Person />
                <Typography variant="body1">Login</Typography>
              </Box>
            )}
          </Button>

          {/* CART BUTTON */}
          <IconButton color="inherit" component={Link} to="/cart">
            <Badge badgeContent={cart.length} color="secondary">
              <ShoppingCart />
            </Badge>
          </IconButton>

        </Box>
      </Toolbar>
    </AppBar>
  );
}