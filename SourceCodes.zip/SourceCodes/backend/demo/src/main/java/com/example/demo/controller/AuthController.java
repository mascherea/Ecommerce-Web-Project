package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // REGISTER ENDPOINT
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        // 1. Check if username exists
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Username already exists!");
        }

        // 2. Save user (In a real app, you would hash the password here)
        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully!");
    }

    // LOGIN ENDPOINT
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginRequest) {
        Optional<User> user = userRepository.findByUsername(loginRequest.getUsername());

        // 1. Check if user exists and password matches
        if (user.isPresent() && user.get().getPassword().equals(loginRequest.getPassword())) {
            // Return the user object (excluding password ideally, but this works for now)
            return ResponseEntity.ok(user.get());
        }

        return ResponseEntity.status(401).body("Invalid username or password");
    }
}