package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int stock = 50;
    private String name;
    private String category;
    private Double price;
    private String imageUrl;
    private int reviewCount = 0;

    // REMOVED: private String description;

    // --- CONSTRUCTORS ---
    public Product() {}

    public Product(String name, String category, Double price, String imageUrl, int reviewCount, int stock) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.imageUrl = imageUrl;
        this.reviewCount = reviewCount;
        this.stock = stock;
    }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }


    // --- GETTERS AND SETTERS ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public int getReviewCount() { return reviewCount; }
    public void setReviewCount(int reviewCount) { this.reviewCount = reviewCount; }
}