package com.example.demo.controller;

import com.example.demo.model.Category;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/categories")
@CrossOrigin(origins = "http://localhost:5173")
public class CategoryController {

    @GetMapping
    public List<Category> getCategories() {
        return Arrays.asList(
                // 1. Protein - Transparent PNG
                new Category(1L, "Protein Powder", "https://cdn-icons-png.flaticon.com/512/4257/4257086.png"),

                // 2. Creatine - Transparent PNG
                new Category(2L, "Creatine", "https://cdn-icons-png.flaticon.com/512/12639/12639996.png"),

                // 3. BCAA - Transparent PNG (Replaces the broken Base64)
                new Category(3L, "BCAA", "https://cdn-icons-png.flaticon.com/512/4257/4257096.png"),

                // 4. Mass Gainer - Transparent PNG
                new Category(4L, "Mass Gainer", "https://cdn-icons-png.flaticon.com/512/2312/2312814.png")
        );
    }
}