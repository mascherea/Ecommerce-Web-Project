package com.example.demo.service;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    // 1. Get All Products (From Database)
    public List<Product> getAll() {
        return repository.findAll();
    }

    // 2. Get By Category
    public List<Product> getByCategory(String category) {
        return repository.findByCategoryIgnoreCase(category);
    }

    // 3. Search & Filter Logic
    public List<Product> searchProducts(String query, Double min, Double max, String sort) {
        List<Product> products;

        // Step 1: Fetch based on search query
        if (query != null && !query.isEmpty()) {
            products = repository.searchProducts(query);
        } else {
            products = repository.findAll();
        }

        // Step 2: Filter by Price (in memory for simplicity)
        if (min != null) {
            products = products.stream().filter(p -> p.getPrice() >= min).collect(Collectors.toList());
        }
        if (max != null) {
            products = products.stream().filter(p -> p.getPrice() <= max).collect(Collectors.toList());
        }

        // Step 3: Sort
        if ("price_asc".equals(sort)) {
            products.sort((p1, p2) -> p1.getPrice().compareTo(p2.getPrice()));
        } else if ("price_desc".equals(sort)) {
            products.sort((p1, p2) -> p2.getPrice().compareTo(p1.getPrice()));
        }

        return products;
    }
    public void purchaseProducts(List<Long> productIds) {
        for (Long id : productIds) {
            Product product = repository.findById(id).orElse(null);
            if (product != null && product.getStock() > 0) {
                product.setStock(product.getStock() - 1);
                repository.save(product);
            }
        }
    }

    // 4. Add Review (Increment Count and Save to DB)
    public Product addReview(Long id) {
        Product product = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        product.setReviewCount(product.getReviewCount() + 1);
        return repository.save(product); // Updates the DB row
    }
}