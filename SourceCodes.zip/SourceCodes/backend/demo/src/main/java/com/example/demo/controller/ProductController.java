package com.example.demo.controller;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService;
import org.springframework.http.ResponseEntity; // Add this import
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping
    public List<Product> getAll() {
        return service.getAll();
    }

    @GetMapping("/category/{category}")
    public List<Product> getByCategory(@PathVariable String category) {
        return service.getByCategory(category);
    }

    @GetMapping("/search")
    public List<Product> search(
            @RequestParam String q,
            @RequestParam(required = false) Double min,
            @RequestParam(required = false) Double max,
            @RequestParam(required = false) String sort
    ) {
        return service.searchProducts(q, min, max, sort);
    }
    @PostMapping("/purchase")
    public ResponseEntity<String> purchaseProducts(@RequestBody List<Long> productIds) {
        service.purchaseProducts(productIds);
        return ResponseEntity.ok("Purchase successful, stock updated!");
    }

    // --- ADD THIS NEW METHOD HERE ---
    @PostMapping("/{id}/review")
    public ResponseEntity<Product> addReview(@PathVariable Long id) {
        try {
            Product updatedProduct = service.addReview(id);
            return ResponseEntity.ok(updatedProduct);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}