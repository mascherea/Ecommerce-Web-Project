

package com.example.demo.model; // Adjust package name if needed

public class Category {
    private Long id;
    private String name;
    private String imageUrl;

    public Category(Long id, String name, String imageUrl) {
        this.id = id;
        this.name = name;
        this.imageUrl = imageUrl;
    }

    // Getters
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getImageUrl() { return imageUrl; }
}